from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    age = models.CharField(max_length=20)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    source = models.CharField(max_length=100)
    aiInterest = models.CharField(max_length=10)
    comments = models.TextField(blank=True, null=True)  # ✅ optional

    birthYear = models.IntegerField(default=2000)
    std = models.CharField(max_length=20, default="NA")
    schoolName = models.CharField(max_length=150, default="NA")
    location = models.CharField(max_length=100, default="Mumbai")

    LANGUAGE_CHOICES = [
        ('Hindi', 'Hindi'),
        ('English', 'English'),
        ('Marathi', 'Marathi'),
    ]
    preferredLanguage = models.CharField(
        max_length=20,
        choices=LANGUAGE_CHOICES,
        default="English"
    )

    created_at = models.DateTimeField(auto_now_add=True)  # ⭐ extra field (best practice)

    def __str__(self):
        return self.name