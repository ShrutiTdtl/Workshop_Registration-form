from django.db import models

class Registration(models.Model):
    # Descriptive field names
    fullName      = models.CharField(max_length=100)        # Stores 'name' from frontend
    email         = models.EmailField()
    phone         = models.CharField(max_length=15)

    parentName    = models.CharField(max_length=100, blank=True, null=True)
    parentPhone   = models.CharField(max_length=15,  blank=True, null=True)

    yourAge       = models.CharField(max_length=20)         # Stores 'age' from frontend
    birthYear     = models.CharField(max_length=10)

    studentClass  = models.CharField(max_length=50)        # Stores 'class' from frontend
    location      = models.CharField(max_length=150)

    # Generic field to store School, College, or Company Name
    institutionName = models.CharField(max_length=150)     # Stores 'schoolName' from frontend

    LANGUAGE_CHOICES = [
        ('English', 'English'),
        ('Hindi',   'Hindi'),
        ('Marathi', 'Marathi'),
    ]
    preferredLanguage = models.CharField(
        max_length=20,
        choices=LANGUAGE_CHOICES
    )

    source = models.CharField(max_length=50)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.fullName