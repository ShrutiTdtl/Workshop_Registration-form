from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    age = models.CharField(max_length=20)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    source = models.CharField(max_length=50)
    aiInterest = models.CharField(max_length=10)
    comments = models.TextField()

    def __str__(self):
        return self.name