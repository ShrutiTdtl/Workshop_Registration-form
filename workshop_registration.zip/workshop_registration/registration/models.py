from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)  # Full Name
    email = models.EmailField()              # Email Address
    phone = models.CharField(max_length=15)  # Phone Number

    parentName = models.CharField(max_length=100, blank=True, null=True)
    parentPhone = models.CharField(max_length=15, blank=True, null=True)

    age = models.CharField(max_length=20)    # Age dropdown
    birthYear = models.IntegerField()        # Birth Year dropdown

    std = models.CharField(max_length=20)    # STD / Class
    location = models.CharField(max_length=100)  # City / Area

    schoolName = models.CharField(max_length=150)

    LANGUAGE_CHOICES = [
        ('Hindi', 'Hindi'),
        ('English', 'English'),
        ('Marathi', 'Marathi'),
    ]
    preferredLanguage = models.CharField(
        max_length=20,
        choices=LANGUAGE_CHOICES
    )

    SOURCE_CHOICES = [
        ('Instagram', 'Instagram'),
        ('WhatsApp', 'WhatsApp'),
        ('Facebook','Facebook'),
        ('LinkedIn', 'LinkedIn'),
        ('Other', 'Other'),
    ]
    source = models.CharField(
        max_length=50,
        choices=SOURCE_CHOICES
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name