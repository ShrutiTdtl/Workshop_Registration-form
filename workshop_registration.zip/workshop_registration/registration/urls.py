from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_user),
    path('registrations/', views.get_registrations),
]