from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Registration
from .serializers import RegistrationSerializer


@api_view(['POST'])
def register(request):
    print("DATA RECEIVED:", request.data)

    serializer = RegistrationSerializer(data=request.data)

    if serializer.is_valid():
        serializer.save()
        return Response(
            {"message": "Data stored successfully"},
            status=status.HTTP_201_CREATED
        )

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_registrations(request):
    data = Registration.objects.all().order_by('-id')  # latest first
    serializer = RegistrationSerializer(data, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)