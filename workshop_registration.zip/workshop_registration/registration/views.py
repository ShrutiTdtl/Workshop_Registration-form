from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Registration
from .serializers import RegistrationSerializer

@api_view(['POST'])
def register(request):
    print("DATA RECEIVED:", request.data)   # 🔥 DEBUG LINE

    serializer = RegistrationSerializer(data=request.data)
    
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Data stored successfully"})
    
    return Response(serializer.errors)

@api_view(['GET'])
def get_registrations(request):
    data = Registration.objects.all()
    serializer = RegistrationSerializer(data, many=True)
    return Response(serializer.data)