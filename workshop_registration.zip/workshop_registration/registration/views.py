from django.core.mail import send_mail
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from registration.models import Registration
from registration.serializers import RegistrationSerializer

@api_view(['POST'])
def register_user(request):
    serializer = RegistrationSerializer(data=request.data)

    if serializer.is_valid():
        registration = serializer.save()
        
        # Send confirmation email
        try:
            subject = 'Registration Successful - AI Gurukul Workshop'
            message = f'Hi {registration.fullName},\n\n' \
                      f'Thank you for registering for the AI Gurukul Workshop!\n\n' \
                      f'Registration Details:\n' \
                      f'- Name: {registration.fullName}\n' \
                      f'- Institution: {registration.institutionName}\n' \
                      f'- Phone: {registration.phone}\n\n' \
                      f'We will get back to you soon with more details.\n' \
                      f'Best regards,\nTeam AI Gurukul'
            
            emails_sent = send_mail(
                subject,
                message,
                settings.DEFAULT_FROM_EMAIL,
                [registration.email],
                fail_silently=False,
            )
            print(f"DEBUG: Email status - {emails_sent} email(s) sent to {registration.email}")
            
        except Exception as e:
            print(f"CRITICAL EMAIL ERROR: {str(e)}")
            import traceback
            traceback.print_exc()

        return Response(
            {"message": "Data stored successfully and confirmation email sent"},
            status=status.HTTP_201_CREATED
        )

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_registrations(request):
    data = Registration.objects.all().order_by('-id')
    serializer = RegistrationSerializer(data, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)