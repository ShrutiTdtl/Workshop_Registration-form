from rest_framework import serializers
from .models import Registration

class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Registration
        fields = '__all__'
    def validate_phone(self, value):
        if len(value) != 10:
            raise serializers.ValidationError("Phone must be 10 digits")
        return value