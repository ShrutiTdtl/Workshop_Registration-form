import rest_framework.serializers as serializers
from registration.models import Registration

class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Registration
        fields = [
            'fullName', 'email', 'phone', 'parentName', 'parentPhone', 
            'yourAge', 'birthYear', 'studentClass', 'location', 
            'institutionName', 'preferredLanguage', 'source', 'created_at'
        ]

    def to_internal_value(self, data):
        # Map frontend keys to descriptive backend fields
        if 'name' in data:
            data['fullName'] = data.pop('name')
            
        if 'age' in data:
            data['yourAge'] = data.pop('age')
            
        if 'class' in data:
            data['studentClass'] = data.pop('class')
            
        if 'schoolName' in data:
            data['institutionName'] = data.pop('schoolName')
            
        return super().to_internal_value(data)

    def to_representation(self, instance):
        # Optional: Map back for GET responses if you want frontend to see original keys
        representation = super().to_representation(instance)
        representation['name'] = representation.pop('fullName')
        representation['age'] = representation.pop('yourAge')
        representation['class'] = representation.pop('studentClass')
        representation['schoolName'] = representation.pop('institutionName')
        return representation

    def validate_phone(self, value):
        if not value.isdigit():
            raise serializers.ValidationError("Phone must contain only digits")
        if len(value) < 10:
             raise serializers.ValidationError("Phone must be at least 10 digits")
        return value

    def validate(self, data):
        # Ensure phone is unique
        if Registration.objects.filter(phone=data.get('phone')).exists():
            # Check if it's the same instance (for updates, if any)
            if not self.instance or self.instance.phone != data.get('phone'):
                raise serializers.ValidationError({"phone": "Phone number already registered"})
        return data