from django.contrib import admin
from registration.models import Registration

@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display  = ('fullName', 'email', 'phone', 'yourAge', 'institutionName', 'created_at')
    search_fields = ('fullName', 'email', 'phone')
    list_filter   = ('yourAge', 'preferredLanguage', 'source')