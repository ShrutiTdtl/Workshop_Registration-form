from django.contrib import admin
from .models import Registration

@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'std', 'location', 'created_at')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('preferredLanguage', 'source')